import xmlrpc.client
import os
import sys
import argparse

def verify_odoo_cron(url, db, username, password):
    """Verify Odoo cron job existence."""
    try:
        common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
        uid = common.authenticate(db, username, password, {})
        
        if not uid:
            print(f"ERROR: Authentication failed for user {username}")
            return False
            
        models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))
        
        # Check for the specific cron
        cron_name = "Social Media Scraper: Run Queue Worker"
        cron_ids = models.execute_kw(db, uid, password, 'ir.cron', 'search', 
            [[['name', '=', cron_name]]])
            
        if cron_ids:
            print(f"✅ Cron job found: '{cron_name}' (ID: {cron_ids[0]})")
            
            # Get details
            cron_data = models.execute_kw(db, uid, password, 'ir.cron', 'read', 
                [cron_ids, ['active', 'interval_number', 'interval_type', 'nextcall']])
            
            data = cron_data[0]
            print(f"   Active: {data['active']}")
            print(f"   Interval: {data['interval_number']} {data['interval_type']}")
            print(f"   Next Call: {data['nextcall']}")
            return True
        else:
            print(f"❌ Cron job NOT found: '{cron_name}'")
            return False
            
    except Exception as e:
        print(f"ERROR: Connection or execution failed: {e}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Verify Odoo Cron")
    parser.add_argument("--url", default="http://localhost:8069", help="Odoo URL")
    parser.add_argument("--db", required=True, help="Odoo Database")
    parser.add_argument("--user", required=True, help="Odoo Username")
    parser.add_argument("--password", required=True, help="Odoo Password")
    
    args = parser.parse_args()
    
    success = verify_odoo_cron(args.url, args.db, args.user, args.password)
    sys.exit(0 if success else 1)
