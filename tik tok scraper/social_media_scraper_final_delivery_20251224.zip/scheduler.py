#!/usr/bin/env python3
"""
Main entry point for the scraper scheduler.
Redirects to worker_apscheduler.py.
"""
import asyncio
import sys
from worker_apscheduler import main

if __name__ == "__main__":
    print("Starting Social Media Scraper Scheduler...")
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutdown by user")
        sys.exit(0)
    except Exception as e:
        print(f"\nFatal error: {e}")
        sys.exit(1)
