import os
import argparse
import json
import sys
from datetime import datetime, timedelta
from dotenv import load_dotenv
from supabase_utils import init_supabase

load_dotenv()

def verify_db_writes(json_output=False, days=1):
    """Verify database writes and output results."""
    # Initialize Supabase
    try:
        supabase = init_supabase(
            os.environ.get("SUPABASE_URL", ""),
            os.environ.get("SUPABASE_KEY", "")
        )
    except Exception as e:
        error_msg = f"Failed to initialize Supabase: {e}"
        if json_output:
            print(json.dumps({"status": "error", "message": str(e)}))
        else:
            print(f"ERROR: {error_msg}")
        return False

    if not supabase:
        error_msg = "Supabase client is None"
        if json_output:
            print(json.dumps({"status": "error", "message": error_msg}))
        else:
            print(f"ERROR: {error_msg}")
        return False

    try:
        # Get total record count
        result_all = supabase.table('tiktok').select('id', count='exact').execute()
        total_records = result_all.count if hasattr(result_all, 'count') else len(result_all.data)

        # Get records from last N days
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        result_recent = supabase.table('tiktok').select('id', count='exact').gte('scraped_at', cutoff).execute()
        recent_records = result_recent.count if hasattr(result_recent, 'count') else len(result_recent.data)

        # Get latest 5 records for sample
        result_sample = supabase.table('tiktok').select(
            'id,topic,engagement_score,posts,views,scraped_at,platform'
        ).order('scraped_at', desc=True).limit(5).execute()

        report = {
            "status": "success",
            "timestamp": datetime.now().isoformat(),
            "table": "tiktok",
            "total_records": total_records,
            "recent_records": recent_records,
            "days_checked": days,
            "sample_records": result_sample.data
        }

        if json_output:
            print(json.dumps(report, indent=2, default=str))
        else:
            print("=" * 60)
            print("DATABASE WRITE VERIFICATION REPORT")
            print("=" * 60)
            print(f"Timestamp: {report['timestamp']}")
            print(f"Table Checked: tiktok")
            print(f"Total records: {total_records}")
            print(f"Records in last {days} days: {recent_records}")
            print("-" * 60)
            print("Latest 5 records:")
            for r in result_sample.data:
                topic = r.get('topic') or "N/A"
                print(f"ID: {r.get('id', 0):5d} | Topic: {topic[:30]:30s} | Score: {r.get('engagement_score', 0):5.2f} | Time: {r.get('scraped_at', '')[:19]}")
            print("=" * 60)
            if recent_records == 0:
                print("[WARNING] No records found in the last 24 hours!")
            else:
                print("[OK] DATABASE WRITES CONFIRMED")
            print("=" * 60)

        return True

    except Exception as e:
        error_msg = f"Database verification failed: {str(e)}"
        if json_output:
            print(json.dumps({"status": "error", "message": error_msg}))
        else:
            print(f"\n[ERROR] {error_msg}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Verify Supabase writes")
    parser.add_argument("--json", action="store_true", help="Output in JSON format")
    parser.add_argument("--days", type=int, default=1, help="Days lookback (default: 1)")
    args = parser.parse_args()

    success = verify_db_writes(json_output=args.json, days=args.days)
    sys.exit(0 if success else 1)
