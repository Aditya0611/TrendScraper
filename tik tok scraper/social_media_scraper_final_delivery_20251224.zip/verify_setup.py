import os
import sys
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("Verification")

def verify_local_cache():
    logger.info("Verifying Local Cache...")
    try:
        from cache_manager import LocalCache
        cache = LocalCache()
        
        # Test write
        test_data = [{"topic": "test_trend", "score": 100}]
        cache.set_trend_data("test_trend", test_data, platform="TikTok")
        
        # Test read
        cached = cache.get_trend_data("test_trend", platform="TikTok")
        if cached and cached[0]["score"] == 100:
            logger.info("✅ Local Cache: Read/Write successful")
        else:
            logger.error("❌ Local Cache: Read failed or data mismatch")
            
        # Test offline queue
        cache.queue_offline_upload("test_table", test_data)
        logger.info("✅ Local Cache: Offline queue successful")
        
    except Exception as e:
        logger.error(f"❌ Local Cache Verification Failed: {e}")

def verify_job_queue():
    logger.info("Verifying Job Queue Module...")
    try:
        from job_queue import JobQueue
        # We can't easily test Supabase connection without creds, but we can check import and class init
        # Mock supabase client
        class MockSupabase:
            pass
            
        queue = JobQueue(MockSupabase())
        logger.info("✅ Job Queue: Module imported and initialized successfully")
    except Exception as e:
        logger.error(f"❌ Job Queue Verification Failed: {e}")

def verify_odoo_sync():
    logger.info("Verifying Odoo Sync Module...")
    try:
        from odoo_sync import OdooSync
        # Just check import and init (will log warnings for missing env vars, which is expected)
        syncer = OdooSync()
        logger.info("✅ Odoo Sync: Module imported and initialized successfully")
    except Exception as e:
        logger.error(f"❌ Odoo Sync Verification Failed: {e}")

def verify_worker_integration():
    logger.info("Verifying Worker Integration...")
    try:
        from worker_apscheduler import APSchedulerWorker, ODOO_SYNC_AVAILABLE, JOB_QUEUE_AVAILABLE
        
        if ODOO_SYNC_AVAILABLE:
            logger.info("✅ Worker: Odoo Sync available")
        else:
            logger.error("❌ Worker: Odoo Sync NOT available")
            
        if JOB_QUEUE_AVAILABLE:
            logger.info("✅ Worker: Job Queue available")
        else:
            logger.error("❌ Worker: Job Queue NOT available")
            
    except Exception as e:
        logger.error(f"❌ Worker Integration Verification Failed: {e}")

if __name__ == "__main__":
    print("="*50)
    print("STARTING VERIFICATION")
    print("="*50)
    
    verify_local_cache()
    verify_job_queue()
    verify_odoo_sync()
    verify_worker_integration()
    
    print("="*50)
    print("VERIFICATION COMPLETE")
    print("="*50)
