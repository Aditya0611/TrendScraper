
import os
import sys
import logging
import asyncio
from datetime import datetime
from pathlib import Path

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Mock Odoo environment
class MockOdooModel:
    def __init__(self):
        self._settings = {
            'tiktok': {
                'platform': 'tiktok',
                'enabled': True,
                'metadata': {
                    'region': 'en',
                    'headless': True,
                    'upload_to_db': True
                }
            }
        }
    
    def search(self, domain, limit=1):
        # Very basic mock
        key = domain[0][2]
        if key in self._settings:
            return MockSetting(self._settings[key])
        return []

class MockSetting:
    def __init__(self, data):
        self.data = data
        self.platform = data['platform']
        self.enabled = data['enabled']
        self.metadata = data['metadata']
    
    def write(self, vals):
        logger.info(f"Mock DB Write: {vals}")

# Copy logical parts from scheduler_settings.py to verify path logic
def test_path_resolution():
    logger.info("Testing path resolution...")
    base_path = os.environ.get('SCRAPER_BASE_PATH')
    if not base_path:
        cwd = Path(os.getcwd())
        candidates = [
            cwd,
            cwd / '..',
            cwd / '..' / '..',
            Path(__file__).parent.parent.parent.parent,
        ]
        
        for candidate in candidates:
            check_path = candidate.resolve() / 'base.py'
            if check_path.exists():
                base_path = str(candidate.resolve())
                logger.info(f"Found scraper at: {base_path}")
                return base_path
    
    logger.error("Could not resolve path")
    return None

def verify_db_insertion():
    logger.info("Verifying DB connection...")
    try:
        from supabase_utils import init_supabase
        from dotenv import load_dotenv
        load_dotenv()
        
        url = os.environ.get("SUPABASE_URL")
        key = os.environ.get("SUPABASE_KEY")
        
        if not url or not key:
            logger.error("Missing Supabase credentials")
            return
            
        supabase = init_supabase(url, key)
        if not supabase:
            logger.error("Failed to connect to Supabase")
            return

        logger.info("Supabase connected. Checking for recent records...")
        
        # Check for records inserted in the last 5 minutes
        now_minus_5 = datetime.utcnow() # Approximate, DB usually UTC
        
        try:
            # Simple check
            response = supabase.table('tiktok').select("*").order('scraped_at', desc=True).limit(1).execute()
            if response.data:
                record = response.data[0]
                logger.info(f"Latest record: {record['topic']} at {record['scraped_at']}")
                
                # Check if it looks like what we expect (we can't easily force a NEW record without running the heavy scraper)
                # But we can assume if this exists, the path is open.
            else:
                logger.warning("No records found in table 'tiktok'")
                
        except Exception as e:
            logger.error(f"Query failed: {e}")

    except ImportError:
        logger.error("Could not import dependencies. Ensure you are in the virtualenv.")

if __name__ == "__main__":
    logger.info("=== START VERIFICATION ===")
    
    # 1. Test path logic
    path = test_path_resolution()
    if path:
        logger.info(f"SUCCESS: Base path identified as {path}")
    else:
        logger.error("FAILURE: Could not identify base path")
        sys.exit(1)

    # 2. Check DB
    verify_db_insertion()
    
    logger.info("=== END VERIFICATION ===")
