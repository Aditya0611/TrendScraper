import os
import sys
import time
import logging
import uuid
from datetime import datetime
from typing import List, Optional
from pathlib import Path
from playwright.sync_api import sync_playwright

# Local modules
from models import Config, PLATFORM_NAME, VERSION_ID
from auth import login_instagram, verify_logged_in
from discovery import discover_hashtags
from engagement import analyze_hashtag_engagement
from db import save_trends_to_database
from observability import setup_structured_logging, metrics
from scraper_run_logger import ScraperRunLogger
from supabase import create_client, Client

# Initialize logging
LOG_FILE_NAME = "instagram_scraper.log"
LOG_DIR = Path(__file__).parent
LOG_FILE_PATH = LOG_DIR / LOG_FILE_NAME

logger = setup_structured_logging(str(LOG_FILE_PATH))
run_logger: Optional[ScraperRunLogger] = None

def run_scraper_job(supabase: Client, run_once: bool = False):
    """Main orchestration job for the scraper."""
    import models
    models.VERSION_ID = str(uuid.uuid4())
    global run_logger
    run_logger = ScraperRunLogger(supabase, models.VERSION_ID)
    run_logger.start_run()
    logger.info(f"Starting scraper run {models.VERSION_ID}")
    
    with sync_playwright() as p:
        # Browser setup with proxies
        # (This logic is simplified for the example, actual implementation uses proxy_wrappers)
        browser = p.chromium.launch(headless=Config.HEADLESS)
        context = browser.new_context()
        page = context.new_page()
        
        try:
            # 1. Login
            if not login_instagram(page):
                logger.error("Failed to login to Instagram")
                return
            
            # 2. Discovery
            trending_hashtags = discover_hashtags(page)
            if not trending_hashtags:
                logger.warning("No hashtags discovered")
                return
                
            # 3. Engagement Analysis
            trend_records = []
            for hashtag_info in trending_hashtags:
                engagement_data = analyze_hashtag_engagement(page, hashtag_info)
                if engagement_data:
                    from models import TrendRecord
                    record = TrendRecord.from_instagram_data(hashtag_info, engagement_data, models.VERSION_ID)
                    trend_records.append(record)
            
            # 4. Save to DB (Unified Path)
            if trend_records:
                save_trends_to_database(supabase, trend_records)
                logger.info(f"Run completed successfully. Saved {len(trend_records)} trends.")
            
        except Exception as e:
            logger.exception(f"Critical error during scraper run: {e}")
        finally:
            browser.close()

if __name__ == "__main__":
    # Validate config
    if not Config.validate():
        sys.exit(1)
        
    # Initialize Supabase
    supabase: Client = create_client(Config.SUPABASE_URL, Config.SUPABASE_KEY)
    # run_logger will be initialized inside run_scraper_job
    
    # Simple CLI argument handling
    if "--run-once" in sys.argv:
        run_scraper_job(supabase, run_once=True)
    else:
        # Scheduler logic here
        pass