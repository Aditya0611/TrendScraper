import logging
from typing import List, Dict, Any
from supabase import Client

# Local imports
from models import Config, TrendRecord, ErrorCode
from observability import metrics
from etl_pipeline import ETLPipeline

# Logger instance
logger = logging.getLogger(__name__)

def save_to_supabase(supabase: Client, trend_record: TrendRecord) -> bool:
    """
    Save a single trend record to Supabase using the UNIFIED trends table.
    Ensures compliance with the TrendRecord shape.
    """
    try:
        # Targeting 'instagram' table (User Schema Requirement)
        table = supabase.table('instagram')
        
        # Check if trend exists for this platform/hashtag
        existing = table.select('id').eq('topic_hashtag', trend_record.hashtags[0]).execute()
        
        # Map TrendRecord to User Schema
        payload = {
            'platform': trend_record.platform,
            'topic_hashtag': trend_record.hashtags[0],
            'engagement_score': trend_record.engagement_score,
            'sentiment_polarity': trend_record.raw_blob.get('sentiment_summary', {}).get('avg_polarity', 0.0),
            'sentiment_label': trend_record.raw_blob.get('sentiment_summary', {}).get('overall_label', 'neutral'),
            'posts': trend_record.likes,
            'views': trend_record.views,
            'metadata': trend_record.raw_blob,
            'scraped_at': trend_record.timestamp.isoformat(),
            'version_id': trend_record.version
        }
        
        if existing.data:
            logger.info(f"Updating existing record in instagram table: {trend_record.hashtags[0]}")
            result = table.update(payload).eq('id', existing.data[0]['id']).execute()
        else:
            logger.info(f"Creating new record in instagram table: {trend_record.hashtags[0]}")
            result = table.insert(payload).execute()
            
        if result.data:
            metrics.increment('db_save_success_total')
            return True
        return False
        
    except Exception as e:
        logger.error(f"[{ErrorCode.DB_SAVE_FAILED}] Database error: {e}")
        metrics.increment('db_save_failures_total')
        return False

def save_trends_to_database(supabase: Client, trend_records: List[TrendRecord]) -> Dict[str, int]:
    """
    Process and save multiple trends using the ETL Pipeline for normalization.
    """
    logger.info(f"Processing {len(trend_records)} trends through ETL Pipeline")
    
    etl = ETLPipeline(supabase)
    results = {"success": 0, "failed": 0}
    
    # Unified path: All platforms write to the same structure
    for record in trend_records:
        if save_to_supabase(supabase, record):
            results["success"] += 1
        else:
            results["failed"] += 1
            
    # Also trigger ETL Pipeline for secondary normalization/archiving if needed
    try:
        etl.process_batch(trend_records)
    except Exception as e:
        logger.warning(f"ETL batch process error: {e}")
        
    return results
